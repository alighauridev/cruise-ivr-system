import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import sql from '@/lib/db';
import { injectTTSIntoCall, getConversationHistory, getAiTask } from '@/server/media-ws';
import { generateConversationResponse } from '@/server/conversation-engine';

export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { callId } = await req.json();
  if (!callId) return NextResponse.json({ error: 'callId required' }, { status: 400 });

  const rows = await sql`
    SELECT id, status FROM calls
    WHERE id = ${callId} AND user_id = ${session.user.id}
    LIMIT 1
  `;
  if (rows.length === 0) return NextResponse.json({ error: 'Call not found' }, { status: 404 });
  if (rows[0].status !== 'ai_conversation') {
    return NextResponse.json({ error: 'Call is not in ai_conversation mode' }, { status: 400 });
  }

  const history = getConversationHistory(callId);
  if (history === null) {
    return NextResponse.json({ error: 'No active conversation session' }, { status: 503 });
  }

  const aiTask = getAiTask(callId);
  const response = await generateConversationResponse(history, callId, aiTask);
  if (!response) {
    return NextResponse.json({ ok: false, message: 'AI chose to stay silent' });
  }

  const injected = await injectTTSIntoCall(callId, response);
  if (!injected) {
    return NextResponse.json({ error: 'Injection failed — WebSocket may be closed' }, { status: 503 });
  }

  return NextResponse.json({ ok: true, text: response });
}
